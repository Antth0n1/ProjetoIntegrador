
require('dotenv').config();
const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

async function setup() {
    console.log('Iniciando configuração do banco de dados...');

    const config = {
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        port: process.env.DB_PORT,
        multipleStatements: true
    };

    try {
        const connection = await mysql.createConnection(config);
        console.log('Conectado ao MySQL!');

        const sqlPath = path.join(__dirname, 'projeto_extensao.sql');
        const sql = fs.readFileSync(sqlPath, 'utf8');

        console.log('Executando script SQL...');
        await connection.query(sql);
        console.log('Banco de dados configurado com sucesso!');

        // Verificar se o usuário admin existe
        await connection.query('USE ' + process.env.DB_NAME);
        const [rows] = await connection.query('SELECT * FROM Usuario WHERE usuario = "admin"');
        if (rows.length === 0) {
            console.log('Criando usuário admin padrão...');
            // Inserir admin (senha admin123)
            // Nota: Em produção, senhas devem ser hash (bcrypt), mas o código atual parece usar texto plano ou o SQL não mostra hash.
            // O controller usa `getUserByUsernameAndPassword` com comparação direta?
            // Vamos verificar o model.
            await connection.query('INSERT INTO Usuario (usuario, senha, tipo) VALUES (?, ?, ?)', ['admin', 'admin123', 'admin']);
            console.log('Usuário admin criado: admin / admin123');
        } else {
            console.log('Usuário admin já existe.');
        }

        await connection.end();
        console.log('Configuração concluída.');
    } catch (err) {
        console.error('Erro ao configurar banco de dados:', err);
        process.exit(1);
    }
}

setup();
