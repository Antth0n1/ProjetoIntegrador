const pool = require('./db');

async function checkSchema() {
    try {
        const [columns] = await pool.query('SHOW COLUMNS FROM Linha_Programatica');
        console.log('Columns in Linha_Programatica:', columns);
    } catch (error) {
        console.error('Error checking schema:', error);
    } finally {
        process.exit();
    }
}

checkSchema();
