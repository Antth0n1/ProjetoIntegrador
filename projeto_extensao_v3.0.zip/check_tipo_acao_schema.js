const pool = require('./db');

async function checkSchema() {
    try {
        const [columns] = await pool.query('SHOW COLUMNS FROM Tipo_Acao');
        console.log('Columns in Tipo_Acao:', columns);
    } catch (error) {
        console.error('Error checking schema:', error);
    } finally {
        process.exit();
    }
}

checkSchema();
