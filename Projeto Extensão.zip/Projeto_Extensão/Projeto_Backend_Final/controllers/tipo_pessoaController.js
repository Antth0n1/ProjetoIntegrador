// tipo_pessoaController.js
const tipo_pessoaModel = require('../models/tipo_pessoaModel');

async function listtipo_pessoa(req, res) {
 try {
 const tipo_pessoa = await tipo_pessoaModel.getAlltipo_pessoa();
 res.render('consultas/tipo_pessoa', { dados: tipo_pessoa });
 } catch (error) {
 console.error('Erro ao buscar cursos:', error);
 res.render('error', { message: 'Erro ao buscar cursos', returnLink: '/welcome' });
 }
}

async function filtertipo_pessoa(req, res) {
 const { nome } = req.body;
 try {
 const tipo_pessoa = await tipo_pessoaModel.gettipo_pessoaByNome(nome || '');
 if (!tipo_pessoa || tipo_pessoa.length === 0) {
 res.render('consultas/tipo_pessoa', { dados: [] });
 return;
 }
 res.render('consultas/tipo_pessoa', { dados: tipo_pessoa });
 } catch (error) {
 console.error('Erro ao filtrar curso:', error);
 res.render('error', { message: 'Erro ao filtrar curso', returnLink: '/welcome' });
 }
}

async function addtipo_pessoa(req, res) {
 const { descricao } = req.body;
 try {
 await tipo_pessoaModel.inserttipo_pessoa({ descricao });
 res.redirect('/tipo_pessoa');
 } catch (error) {
 console.error('Erro ao inserir curso:', error);
 res.render('error', { message: 'Erro ao inserir curso', returnLink: '/logo' });
 }
}

async function showtipo_pessoa(req, res) {
 const id = req.params.id;
 try {
 const tipo_pessoa = await tipo_pessoaModel.gettipo_pessoaById(id);
 if (!tipo_pessoa) {
 res.status(404).send('tipo_pessoa não encontrado');
 return;
 }
 res.render('consultas/tipo_pessoa', { dados: [tipo_pessoa] });
 } catch (error) {
 console.error('Erro ao buscar tipo_pessoa:', error);
 res.render('error', { message: 'Erro ao buscar tipo_pessoa', returnLink: '/welcome' });
 }
}

async function showEditFormtipo_pessoa(req, res) {
 const id = req.params.id;
 try {
 const tipo_pessoa = await tipo_pessoaModel.gettipo_pessoaById(id);
 if (!tipo_pessoa) {
 res.status(404).send('tipo_pessoa não encontrado');
 return;
 }
 res.render('forms/curso', { curso, isEdit: true });
 } catch (error) {
 console.error('Erro ao carregar curso para edição:', error);
 res.render('error', { message: 'Erro ao carregar curso para edição', returnLink: '/curso' });
 }
}

async function edittipo_pessoa(req, res) {
 const id = req.params.id;
 const { descricao } = req.body;
 try {
 await tipo_pessoaModel.updatetipo_pessoa(id, { descricao });
 res.redirect('/tipo_pessoa');
 } catch (error) {
 console.error('Erro ao editar curso:', error);
 res.render('error', { message: 'Erro ao editar curso', returnLink: '/curso' });
 }
}

async function showConfirmDeleteFormtipo_pessoa(req, res) {
 const id = req.params.id;
 try {
 const tipo_pessoa = await tipo_pessoaModel.gettipo_pessoaById(id);
 if (!tipo_pessoa) {
 res.status(404).send('tipo_pessoa não encontrado');
 return;
 }
 res.render('confirmDelete', { curso });
 } catch (error) {
 console.error('Erro ao carregar confirmação de exclusão:', error);
 res.render('error', { message: 'Erro ao carregar confirmação de exclusão', returnLink: '/curso' });
 }
}

async function deletetipo_pessoa(req, res) {
 const id = req.params.id;
 try {
 await tipo_pessoaModel.deletetipo_pessoa(id);
 res.redirect('/tipo_pessoa');
 } catch (error) {
 console.error('Erro ao excluir curso:', error);
 res.render('error', { message: 'Erro ao excluir curso', returnLink: '/curso' });
 }
}

module.exports = {
 listtipo_pessoa,
 filtertipo_pessoa,
 addtipo_pessoa,
 showtipo_pessoa,
 showEditFormtipo_pessoa,
 edittipo_pessoa,
 showConfirmDeleteFormtipo_pessoa,
 deletetipo_pessoa
};
