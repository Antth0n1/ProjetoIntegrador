// tipo_acaoController.js
const tipo_acaoModel = require('../models/tipo_acaoModel');

async function listtipo_acao(req, res) {
 try {
 const tipo_acao = await tipo_acaoModel.getAlltipo_acao();
 res.render('consultas/tipo_acao', { dados: tipo_acao });
 } catch (error) {
 console.error('Erro ao buscar cursos:', error);
 res.render('error', { message: 'Erro ao buscar cursos', returnLink: '/welcome' });
 }
}

async function filtertipo_acao(req, res) {
 const { nome } = req.body;
 try {
 const tipo_acao = await tipo_acaoModel.gettipo_acaoByNome(nome || '');
 if (!tipo_acao || tipo_acao.length === 0) {
 res.render('consultas/tipo_acao', { dados: [] });
 return;
 }
 res.render('consultas/tipo_acao', { dados: tipo_acao });
 } catch (error) {
 console.error('Erro ao filtrar curso:', error);
 res.render('error', { message: 'Erro ao filtrar curso', returnLink: '/welcome' });
 }
}

async function addtipo_acao(req, res) {
 const { nome, valor } = req.body;
 try {
 await tipo_acaoModel.inserttipo_acao({ nome, valor });
 res.redirect('/tipo_acao');
 } catch (error) {
 console.error('Erro ao inserir tipo_acao:', error);
 res.render('error', { message: 'Erro ao inserir tipo_acao', returnLink: '/logo' });
 }
}

async function showtipo_acao(req, res) {
 const id = req.params.id;
 try {
 const tipo_acao = await tipo_acaoModel.gettipo_acaoById(id);
 if (!tipo_acao) {
 res.status(404).send('tipo_acao não encontrado');
 return;
 }
 res.render('consultas/tipo_acao', { dados: [tipo_acao] });
 } catch (error) {
 console.error('Erro ao buscar tipo_acao:', error);
 res.render('error', { message: 'Erro ao buscar tipo_acao', returnLink: '/welcome' });
 }
}

async function showEditFormtipo_acao(req, res) {
 const id = req.params.id;
 try {
 const tipo_acao = await tipo_acaoModel.gettipo_acaoById(id);
 if (!tipo_acao) {
 res.status(404).send('tipo_acao não encontrado');
 return;
 }
 res.render('forms/tipo_acao', { tipo_acao, isEdit: true });
 } catch (error) {
 console.error('Erro ao carregar tipo_acao para edição:', error);
 res.render('error', { message: 'Erro ao carregar tipo_acao para edição', returnLink: '/tipo_acao' });
 }
}

async function edittipo_acao(req, res) {
 const id = req.params.id;
 const { nome, valor } = req.body;
 try {
 await tipo_acaoModel.updatetipo_acao(id, { nome, valor });
 res.redirect('/tipo_acao');
 } catch (error) {
 console.error('Erro ao editar tipo_acao:', error);
 res.render('error', { message: 'Erro ao editar tipo_acao', returnLink: '/tipo_acao' });
 }
}

async function showConfirmDeleteFormtipo_acao(req, res) {
 const id = req.params.id;
 try {
 const tipo_acao = await tipo_acaoModel.gettipo_acaoById(id);
 if (!tipo_acao) {
 res.status(404).send('tipo_acao não encontrado');
 return;
 }
 res.render('confirmDelete', { tipo_acao });
 } catch (error) {
 console.error('Erro ao carregar confirmação de exclusão:', error);
 res.render('error', { message: 'Erro ao carregar confirmação de exclusão', returnLink: '/tipo_acao' });
 }
}

async function deletetipo_acao(req, res) {
 const id = req.params.id;
 try {
 await tipo_acaoModel.deletetipo_acao(id);
 res.redirect('/tipo_acao');
 } catch (error) {
 console.error('Erro ao excluir tipo_acao:', error);
 res.render('error', { message: 'Erro ao excluir tipo_acao', returnLink: '/tipo_acao' });
 }
}

module.exports = {
 listtipo_acao,
 filtertipo_acao,
 addtipo_acao,
 showtipo_acao,
 showEditFormtipo_acao,
 edittipo_acao,
 showConfirmDeleteFormtipo_acao,
 deletetipo_acao
};
