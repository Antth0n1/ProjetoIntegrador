// projeto_extensaoController.js
const projeto_extensaoModel = require('../models/projeto_extensaoModel');

// Normaliza o corpo da request para o formato esperado pelo model de projetos de extensao
function mapRequestToRegistro(body) {
  const {
    id_projeto,
    titulo,
    id_tipo_plano,
    coordenador_id,
    periodo_inicio,
    periodo_fim,
    carga_horaria_total,
    id_publico_alvo
  } = body;

  return {
    id_projeto,
    titulo,
    id_tipo_plano,
    coordenador_id,
    periodo_inicio,
    periodo_fim,
    carga_horaria_total,
    id_publico_alvo
  };
}

async function listprojeto_extensaos(req, res) {
  try {
    const projeto_extensaos = await projeto_extensaoModel.getAllprojeto_extensaos();
    res.render('consultas/projeto_extensao', { dados: projeto_extensaos });
  } catch (error) {
    console.error('Erro ao buscar projeto_extensaos:', error);
    res.render('error', { message: 'Erro ao buscar projeto_extensaos', returnLink: '/logo' });
  }
}

async function filterprojeto_extensao(req, res) {
  const { nome } = req.body;
  try {
    const projeto_extensaos = await projeto_extensaoModel.getprojeto_extensaosByNome(nome || '');
    if (!projeto_extensaos || projeto_extensaos.length === 0) {
      res.render('consultas/projeto_extensao', { dados: [] });
      return;
    }
    res.render('consultas/projeto_extensao', { dados: projeto_extensaos });
  } catch (error) {
    console.error('Erro ao filtrar projeto_extensao:', error);
    res.render('error', { message: 'Erro ao filtrar projeto_extensao', returnLink: '/logo' });
  }
}

async function addprojeto_extensao(req, res) {
  try {
    await projeto_extensaoModel.insertprojeto_extensaos(mapRequestToRegistro(req.body));
    res.redirect('/projeto_extensao');
  } catch (error) {
    console.error('Erro ao inserir projeto_extensao:', error);
    res.render('error', { message: 'Erro ao inserir projeto_extensao', returnLink: '/logo' });
  }
}

async function showprojeto_extensao(req, res) {
  const id = req.params.id;
  try {
    const projeto_extensao = await projeto_extensaoModel.getprojeto_extensaosById(id);
    if (!projeto_extensao) {
      res.status(404).send('projeto_extensao nao encontrado');
      return;
    }
    res.render('consultas/projeto_extensao', { dados: [projeto_extensao] });
  } catch (error) {
    console.error('Erro ao buscar projeto_extensao:', error);
    res.render('error', { message: 'Erro ao buscar projeto_extensao', returnLink: '/logo' });
  }
}

async function showEditForm(req, res) {
  const id = req.params.id;
  try {
    const projeto_extensao = await projeto_extensaoModel.getprojeto_extensaosById(id);
    if (!projeto_extensao) {
      res.status(404).send('projeto_extensao nao encontrado');
      return;
    }
    res.render('forms/projeto_extensao', { projeto_extensao, isEdit: true });
  } catch (error) {
    console.error('Erro ao carregar projeto_extensao para edicao:', error);
    res.render('error', { message: 'Erro ao carregar projeto_extensao para edicao', returnLink: '/projeto_extensao' });
  }
}

async function editprojeto_extensao(req, res) {
  const id = req.params.id;
  try {
    await projeto_extensaoModel.updateprojeto_extensaos(id, mapRequestToRegistro(req.body));
    res.redirect('/projeto_extensao');
  } catch (error) {
    console.error('Erro ao editar projeto_extensao:', error);
    res.render('error', { message: 'Erro ao editar projeto_extensao', returnLink: '/projeto_extensao' });
  }
}

async function showConfirmDeleteForm(req, res) {
  const id = req.params.id;
  try {
    const projeto_extensao = await projeto_extensaoModel.getprojeto_extensaosById(id);
    if (!projeto_extensao) {
      res.status(404).send('projeto_extensao nao encontrado');
      return;
    }
    res.render('confirmDelete', { projeto_extensao });
  } catch (error) {
    console.error('Erro ao carregar confirmacao de exclusao:', error);
    res.render('error', { message: 'Erro ao carregar confirmacao de exclusao', returnLink: '/projeto_extensao' });
  }
}

async function deleteprojeto_extensao(req, res) {
  const id = req.params.id;
  try {
    await projeto_extensaoModel.deleteprojeto_extensaos(id);
    res.redirect('/projeto_extensao');
  } catch (error) {
    console.error('Erro ao excluir projeto_extensao:', error);
    res.render('error', { message: 'Erro ao excluir projeto_extensao', returnLink: '/projeto_extensao' });
  }
}

module.exports = {
  listprojeto_extensaos,
  filterprojeto_extensao,
  addprojeto_extensao,
  showprojeto_extensao,
  showEditForm,
  editprojeto_extensao,
  showConfirmDeleteForm,
  deleteprojeto_extensao
};
