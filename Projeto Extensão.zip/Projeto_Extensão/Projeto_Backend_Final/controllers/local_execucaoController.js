const local_execucaoModel = require('../models/local_execucaoModel');

// Normaliza o corpo da request para o formato esperado pelo model
function mapRequestToRegistro(body) {
  const {
    endereco,
    cep,
    bairro,
    cidade
  } = body;

  return {
    endereco,
    cep,
    bairro,
    cidade
  };
}

async function listlocal_execucaos(req, res) {
  try {
    const local_execucaos = await local_execucaoModel.getAlllocal_execucaos();
    res.render('./consultas/local_execucao', { dados: local_execucaos });
  } catch (error) {
    console.error('Erro ao buscar local_execucaos:', error);
    res.render('error', { message: 'Erro ao buscar local_execucaos', returnLink: '/logo' });
  }
}

async function addlocal_execucao(req, res) {
  try {
    await local_execucaoModel.insertlocal_execucao(mapRequestToRegistro(req.body));
    res.redirect('/local_execucao');
  } catch (error) {
    console.error('Erro ao inserir local_execucao:', error);
    res.render('error', { message: 'Erro ao inserir local_execucao', returnLink: '/logo' });
  }
}

async function showlocal_execucao(req, res) {
  const id = req.params.id;
  try {
    const local_execucao = await local_execucaoModel.getlocal_execucaoById(id);
    if (!local_execucao) {
      res.status(404).send('local_execucao nao encontrado');
      return;
    }
    res.render('consultas/local_execucao', { dados: [local_execucao] });
  } catch (error) {
    console.error('Erro ao buscar local_execucao:', error);
    res.render('error', { message: 'Erro ao buscar local_execucao', returnLink: '/logo' });
  }
}

async function showEditForm(req, res) {
  const id = req.params.id;
  try {
    const local_execucao = await local_execucaoModel.getlocal_execucaoById(id);
    if (!local_execucao) {
      res.status(404).send('local_execucao nao encontrado');
      return;
    }
    res.render('forms/local_execucao', { local_execucao, isEdit: true });
  } catch (error) {
    console.error('Erro ao carregar local_execucao para edicao:', error);
    res.render('error', { message: 'Erro ao carregar local_execucao para edicao', returnLink: '/local_execucao' });
  }
}

async function editlocal_execucao(req, res) {
  const id = req.params.id;
  try {
    await local_execucaoModel.updatelocal_execucao(id, mapRequestToRegistro(req.body));
    res.redirect('/local_execucao');
  } catch (error) {
    console.error('Erro ao atualizar local_execucao:', error);
    res.render('error', { message: 'Erro ao atualizar local_execucao', returnLink: '/local_execucao' });
  }
}

async function deletelocal_execucao(req, res) {
  const id = req.params.id;
  try {
    await local_execucaoModel.deletelocal_execucao(id);
    res.redirect('/local_execucao');
  } catch (error) {
    console.error('Erro ao deletar local_execucao:', error);
    res.render('error', { message: 'Erro ao deletar local_execucao', returnLink: '/local_execucao' });
  }
}

module.exports = {
  listlocal_execucaos,
  addlocal_execucao,
  showlocal_execucao,
  showEditForm,
  editlocal_execucao,
  deletelocal_execucao
};
