// projeto_localController.js
const projeto_localModel = require('../models/projeto_localModel');

// Normaliza o corpo da request para o formato esperado pelo model de projetos de local
function mapRequestToRegistro(body) {
  const {
    id_projeto,
    id_local,
    titulo,
    id_tipo_plano,
    coordenador_id,
    periodo_inicio,
    periodo_fim,
    carga_horaria_total,
    id_publico_alvo
  } = body;

  return {
    id_projeto,
    id_local,
    titulo,
    id_tipo_plano,
    coordenador_id,
    periodo_inicio,
    periodo_fim,
    carga_horaria_total,
    id_publico_alvo
  };
}

async function listprojeto_locals(req, res) {
  try {
    const projeto_locals = await projeto_localModel.getAllprojeto_locals();
    res.render('./consultas/projeto_local', { dados: projeto_locals });
  } catch (error) {
    console.error('Erro ao buscar projeto_locals:', error);
    res.render('error', { message: 'Erro ao buscar projeto_locals', returnLink: '/logo' });
  }
}

async function filterprojeto_local(req, res) {
  const { nome } = req.body;
  try {
    const projeto_locals = await projeto_localModel.getprojeto_localsByNome(nome || '');
    if (!projeto_locals || projeto_locals.length === 0) {
      res.render('consultas/projeto_local', { dados: [] });
      return;
    }
    res.render('consultas/projeto_local', { dados: projeto_locals });
  } catch (error) {
    console.error('Erro ao filtrar projeto_local:', error);
    res.render('error', { message: 'Erro ao filtrar projeto_local', returnLink: '/logo' });
  }
}

async function addprojeto_local(req, res) {
  try {
    await projeto_localModel.insertprojeto_locals(mapRequestToRegistro(req.body));
    res.redirect('/projeto_local');
  } catch (error) {
    console.error('Erro ao inserir projeto_local:', error);
    res.render('error', { message: 'Erro ao inserir projeto_local', returnLink: '/logo' });
  }
}

async function showprojeto_local(req, res) {
  const id = req.params.id;
  try {
    const projeto_local = await projeto_localModel.getprojeto_localsById(id);
    if (!projeto_local) {
      res.status(404).send('projeto_local nao encontrado');
      return;
    }
    res.render('consultas/projeto_local', { dados: [projeto_local] });
  } catch (error) {
    console.error('Erro ao buscar projeto_local:', error);
    res.render('error', { message: 'Erro ao buscar projeto_local', returnLink: '/logo' });
  }
}

async function showEditForm(req, res) {
  const id = req.params.id;
  try {
    const projeto_local = await projeto_localModel.getprojeto_localsById(id);
    if (!projeto_local) {
      res.status(404).send('projeto_local nao encontrado');
      return;
    }
    res.render('forms/projeto_local', { projeto_local, isEdit: true });
  } catch (error) {
    console.error('Erro ao carregar projeto_local para edicao:', error);
    res.render('error', { message: 'Erro ao carregar projeto_local para edicao', returnLink: '/projeto_local' });
  }
}

async function editprojeto_local(req, res) {
  const id = req.params.id;
  try {
    await projeto_localModel.updateprojeto_locals(id, mapRequestToRegistro(req.body));
    res.redirect('/projeto_local');
  } catch (error) {
    console.error('Erro ao editar projeto_local:', error);
    res.render('error', { message: 'Erro ao editar projeto_local', returnLink: '/projeto_local' });
  }
}

async function showConfirmDeleteForm(req, res) {
  const id = req.params.id;
  try {
    const projeto_local = await projeto_localModel.getprojeto_localsById(id);
    if (!projeto_local) {
      res.status(404).send('projeto_local nao encontrado');
      return;
    }
    res.render('confirmDelete', { projeto_local });
  } catch (error) {
    console.error('Erro ao carregar confirmacao de exclusao:', error);
    res.render('error', { message: 'Erro ao carregar confirmacao de exclusao', returnLink: '/projeto_local' });
  }
}

async function deleteprojeto_local(req, res) {
  const id = req.params.id;
  try {
    await projeto_localModel.deleteprojeto_locals(id);
    res.redirect('/projeto_local');
  } catch (error) {
    console.error('Erro ao excluir projeto_local:', error);
    res.render('error', { message: 'Erro ao excluir projeto_local', returnLink: '/projeto_local' });
  }
}

module.exports = {
  listprojeto_locals,
  filterprojeto_local,
  addprojeto_local,
  showprojeto_local,
  showEditForm,
  editprojeto_local,
  showConfirmDeleteForm,
  deleteprojeto_local
};
