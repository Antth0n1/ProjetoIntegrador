// tipo_acaoModel.js - acessa a tabela tipo_acao
const pool = require('../db');

function runQuery(sql, params = []) {
  return pool.query(sql, params).then(([rows]) => rows);
}

async function getAlltipo_acao() {
  return runQuery('SELECT id_acao, nome, valor FROM tipo_acao ORDER BY id_acao DESC');
}

async function gettipo_acaoByNome(nome) {
  return runQuery(
    'SELECT * FROM tipo_acao WHERE nome LIKE ? ORDER BY id_acao DESC',
    ['%' + nome + '%']
  );
}

async function gettipo_acaoByNomedelete(nome) {
  const registros = await runQuery(
    'SELECT * FROM tipo_acao WHERE nome = ? ORDER BY id_acao DESC',
    [nome]
  );
  return registros[0];
}

async function inserttipo_acao(registro) {
  await runQuery(
    'INSERT INTO tipo_acao (nome, valor) VALUES (?, ?)',
    [registro['nome'] ?? null, registro['valor'] ?? null]
  );
  const termoBusca = registro['nome'] ?? '';
  return gettipo_acaoByNome(termoBusca);
}

async function gettipo_acaoById(id) {
  const registros = await runQuery(
    'SELECT * FROM tipo_acao WHERE id_acao = ?',
    [id]
  );
  return registros[0];
}

async function deletetipo_acao(id) {
  await runQuery(
    'DELETE FROM tipo_acao WHERE id_acao = ?',
    [id]
  );
}

async function updatetipo_acao(id, registro) {
  await runQuery(
    'UPDATE tipo_acao SET nome = ?, valor = ? WHERE id_acao = ?',
    [registro['nome'] ?? null, registro['valor'] ?? null, id]
  );
  return gettipo_acaoById(id);
}

module.exports = {
  getAlltipo_acao,
  gettipo_acaoByNome,
  gettipo_acaoByNomedelete,
  inserttipo_acao,
  gettipo_acaoById,
  deletetipo_acao,
  updatetipo_acao
};
