const pool = require('../db');

// Lista todos os locais de execução
async function getAlllocal_execucaos() {
  try {
    const [local_execucaos] = await pool.query(
      'SELECT * FROM local_execucao ORDER BY id_local DESC'
    );
    return local_execucaos;
  } catch (error) {
    throw error;
  }
}

// Lista local de execução por ID
async function getlocal_execucaoById(id) {
  try {
    const [local_execucaos] = await pool.query(
      'SELECT * FROM local_execucao WHERE id_local = ?',
      [id]
    );
    return local_execucaos[0];
  } catch (error) {
    throw error;
  }
}

// Insere novo local de execução
async function insertlocal_execucao(registro) {
  try {
    await pool.query(
      'INSERT INTO local_execucao (endereco, cep, bairro, cidade) VALUES (?, ?, ?, ?)',
      [
        registro.endereco ?? null,
        registro.cep ?? null,
        registro.bairro ?? null,
        registro.cidade ?? null
      ]
    );

    const [local_execucaos] = await pool.query(
      'SELECT * FROM local_execucao ORDER BY id_local DESC'
    );
    return local_execucaos;
  } catch (error) {
    throw error;
  }
}

// Deleta local de execução
async function deletelocal_execucao(id) {
  try {
    await pool.query(
      'DELETE FROM local_execucao WHERE id_local = ?',
      [id]
    );
  } catch (error) {
    throw error;
  }
}

// Atualiza local de execução
async function updatelocal_execucao(id, registro) {
  try {
    await pool.query(
      'UPDATE local_execucao SET endereco = ?, cep = ?, bairro = ?, cidade = ? WHERE id_local = ?',
      [
        registro.endereco ?? null,
        registro.cep ?? null,
        registro.bairro ?? null,
        registro.cidade ?? null,
        id
      ]
    );

    return await getlocal_execucaoById(id);
  } catch (error) {
    throw error;
  }
}

module.exports = {
  getAlllocal_execucaos,
  getlocal_execucaoById,
  insertlocal_execucao,
  deletelocal_execucao,
  updatelocal_execucao
};
