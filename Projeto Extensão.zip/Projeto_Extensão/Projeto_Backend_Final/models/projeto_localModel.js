const pool = require('../db');

// Lista todos os projetos de local com os principais campos da tabela e dados de local_execucao
async function getAllprojeto_locals() {
  try {
  const [projeto_locals] = await pool.query(
    `SELECT pl.id_projeto, pl.id_local, le.endereco, le.cep, le.bairro, le.cidade 
     FROM projeto_local pl 
     LEFT JOIN local_execucao le ON pl.id_local = le.id_local 
     ORDER BY pl.id_projeto DESC`
  );
  return projeto_locals;
  }
  catch(error){
    throw error;
  }
}

async function getprojeto_localsByNome(nome)  {
  try {
  const [projeto_locals] = await pool.query(
    `SELECT pl.id_projeto, pl.id_local, le.endereco, le.cep, le.bairro, le.cidade 
     FROM projeto_local pl 
     LEFT JOIN local_execucao le ON pl.id_local = le.id_local 
     ORDER BY pl.id_projeto DESC`
  );
  return projeto_locals;
  } catch (error) {
 throw error;
 }
}

async function getprojeto_localsByNomedelete(nome)  {
  try {
  const [projeto_locals] = await pool.query(
    `SELECT pl.id_projeto, pl.id_local, le.endereco, le.cep, le.bairro, le.cidade 
     FROM projeto_local pl 
     LEFT JOIN local_execucao le ON pl.id_local = le.id_local 
     ORDER BY pl.id_projeto DESC`
  );
 return projeto_locals;
  } catch (error) {
 throw error;
 }
}

async function insertprojeto_locals(registro) {
  try {
  await pool.query(
    'INSERT INTO projeto_local (id_projeto, id_local) VALUES (?, ?)',
    [
      registro.id_projeto ?? null,
      registro.id_local ?? null
    ]
  );

  const [projeto_locals] = await pool.query(
    `SELECT pl.id_projeto, pl.id_local, le.endereco, le.cep, le.bairro, le.cidade 
     FROM projeto_local pl 
     LEFT JOIN local_execucao le ON pl.id_local = le.id_local 
     ORDER BY pl.id_projeto DESC`
  );
  return projeto_locals;
 } catch (error) {
 throw error;
 }
}

async function getprojeto_localsById(id)  {
 try {
 const [projeto_locals] = await pool.query(
    `SELECT pl.id_projeto, pl.id_local, le.endereco, le.cep, le.bairro, le.cidade 
     FROM projeto_local pl 
     LEFT JOIN local_execucao le ON pl.id_local = le.id_local 
     WHERE pl.id_projeto = ?`,
    [id]
  );
  return projeto_locals[0];
 } catch (error) {
 throw error;
 }
} 

async function deleteprojeto_locals(id) {
  try {
  await pool.query(
    'DELETE FROM projeto_local WHERE id_projeto = ?',
    [id]
  );
} catch (error) {
 throw error;
}
}

async function updateprojeto_locals(id, registro) {
  try {
  await pool.query(
    'UPDATE projeto_local SET id_local = ? WHERE id_projeto = ?',
    [
      registro.id_local ?? null,
      id
    ]
  );

  return await getprojeto_localsById(id);    
 } catch (error) {
 throw error;
}
}module.exports = {  
  getAllprojeto_locals,
  getprojeto_localsByNome,
  getprojeto_localsByNomedelete,
  insertprojeto_locals,
  getprojeto_localsById,
  deleteprojeto_locals,
  updateprojeto_locals
};
