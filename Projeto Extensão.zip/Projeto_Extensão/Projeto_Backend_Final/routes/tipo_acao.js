// tipo_acao.js
const express = require('express');
const router = express.Router();
const tipo_acaoController = require('../controllers/tipo_acaoController');
const tipo_acaoModel = require('../models/tipo_acaoModel');
// Rota para listar todos os tipo_acao
router.get('/', tipo_acaoController.listtipo_acao);
// Rota para listar todos os tipo_acao
router.get('/filtro', (req, res) => {
 res.render('filtro');
 });
router.get('/forms/tipo_acao', (req, res) => {
 res.render('forms/tipo_acao', { tipo_acao: { id_tipo_acao: '', nome_tipo_acao: '' }, isEdit: false });
 });
router.get('/consultas/tipo_acao', async (req, res) => {
 try {
 const dados = await tipo_acaoModel.getAlltipo_acao();
 res.render('consultas/tipo_acao', { dados });
 } catch (error) {
 console.error('Erro ao carregar consulta de tipo_acao:', error);
 res.render('error', { message: 'Erro ao carregar consulta de tipo_acao', returnLink: '/welcome' });
 }
 });
// Rota para filtrar tipo_acao por nome
router.post('/filtro', tipo_acaoController.filtertipo_acao);
router.get('/cadastrar', (req, res) => {
 res.render('cadastrar');
 });
router.post('/cadastrar', tipo_acaoController.addtipo_acao);
router.get('/:id', tipo_acaoController.showtipo_acao);
router.get('/:id/edit', tipo_acaoController.showEditFormtipo_acao);     
router.post('/:id/edit', tipo_acaoController.edittipo_acao);
router.post('/:id/delete', tipo_acaoController.deletetipo_acao);
router.get('/:id/confirm-delete', tipo_acaoController.showConfirmDeleteFormtipo_acao);
module.exports = router; 
