// projeto_local.js  
const express = require('express');
const router = express.Router();
const projeto_localController = require('../controllers/projeto_localController');       
const projeto_localModel = require('../models/projeto_localModel');     
const pool = require('../db');

async function carregarOpcoesProjetolocal() {
 const [tipoPlanos] = await pool.query('SELECT id_tipo_plano, descricao FROM projetos_local.tipo_plano');
 const [coordenadores] = await pool.query(`SELECT pp.id_projeto, pp.id_pessoa
 FROM projetos_local.projeto_pessoa pp
 inner join projetos_local.pessoa p on p.id_pessoa = pp.id_pessoa
 where pp.id_papel = 1`);
 const [publicosAlvo] = await pool.query('SELECT id_publico_alvo, descricao FROM projetos_local.publico_alvo');

 return { tipoPlanos, coordenadores, publicosAlvo };
}
// Rota para listar todos os projeto_local
router.get('/', projeto_localController.listprojeto_locals);
// Rota para listar todos os projeto_local   
router.get('/filtro', (req, res) => {
 res.render('filtro');
 });
router.get('/forms/projeto_local', (req, res) => {
 res.render('forms/projeto_local', { projeto_local:
     {id_projeto: '', id_local: ''}
  , isEdit: false });
 });

router.get('/consultas/projeto_local', async (req, res) => {
 try {
 const dados = await projeto_localModel.getAllprojeto_locals();
 res.render('consultas/projeto_local', { dados });
 } catch (error) {
 console.error('Erro ao carregar consulta de projeto_local:', error);
 res.render('error', { message: 'Erro ao carregar consulta de projeto_local', returnLink: '/logon' });
 }
 });

// Rota para filtrar projeto_locals por nome
router.post('/filtro', projeto_localController.filterprojeto_local);
router.get('/cadastrar', (req, res) => {
 res.render('cadastrar');
 });

router.post('/cadastrar', projeto_localController.addprojeto_local);

router.get('/:id', projeto_localController.showprojeto_local);

// Rota para exibir página de edição de projeto_local
router.get('/:id/edit', projeto_localController.showEditForm); 

// Rota para lidar com ação de edição de projeto_local
router.post('/:id/edit', projeto_localController.editprojeto_local);

// Rota para lidar com ação de exclusão de projeto_local
router.post('/:id/delete', projeto_localController.deleteprojeto_local);

// Rota para exibir formulário de confirmação de exclusão
router.get('/:id/confirm-delete', projeto_localController.showConfirmDeleteForm);

module.exports = router; 
