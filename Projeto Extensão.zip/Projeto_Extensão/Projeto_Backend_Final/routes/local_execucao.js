const express = require('express');
const router = express.Router();
const local_execucaoController = require('../controllers/local_execucaoController');
const local_execucaoModel = require('../models/local_execucaoModel');

// Rota para listar todos os locais de execução
router.get('/', local_execucaoController.listlocal_execucaos);

// Rota para exibir formulário de novo local de execução
router.get('/forms/local_execucao', (req, res) => {
  res.render('forms/local_execucao', { 
    local_execucao: { id_local: '', endereco: '', cep: '', bairro: '', cidade: '' },
    isEdit: false 
  });
});

// Rota para adicionar novo local de execução
router.post('/cadastrar', local_execucaoController.addlocal_execucao);

// Rota para exibir um local de execução específico
router.get('/:id', local_execucaoController.showlocal_execucao);

// Rota para exibir página de edição de local de execução
router.get('/:id/edit', local_execucaoController.showEditForm);

// Rota para atualizar local de execução
router.post('/:id/edit', local_execucaoController.editlocal_execucao);

// Rota para deletar local de execução
router.get('/:id/delete', local_execucaoController.deletelocal_execucao);
router.post('/:id/delete', local_execucaoController.deletelocal_execucao);

module.exports = router;
