// routes/index.js
// index.js
const express = require('express');
const router = express.Router();
const usuarioController = require('../controllers/usuarioController');
const cursoRouter = require('./curso'); 
const faixa_etariaRouter = require('./faixa_etaria');
const escolaridadeRouter = require('./escolaridade');
const tipo_pessoaRouter = require('./tipo_pessoa');
const avaliacao_institucionalRouter = require('./avaliacao_institucional');
const projeto_extensaoRouter = require('./projeto_extensao');
const pessoaRouter = require('./pessoa');
const projeto_localRouter = require('./projeto_local');
const tipo_acaoRouter = require('./tipo_acao');
const local_execucaoRouter = require('./local_execucao');

// Rota GET para exibir a página de login
router.get('/login', (req, res) => {
  res.render('login');
});

router.get('/logo', (req, res) => {
  res.render('logo');
});

// Rota POST para processar o formulário de login
router.post('/login', usuarioController.login);

// Registrar todas as rotas do aplicativo
router.use('/curso', cursoRouter);  
router.use('/faixa_etaria', faixa_etariaRouter);
router.use('/escolaridade', escolaridadeRouter);
router.use('/tipo_pessoa', tipo_pessoaRouter);    
router.use('/avaliacao_institucional', avaliacao_institucionalRouter);      
router.use('/projeto_extensao', projeto_extensaoRouter);      
router.use('/projeto_local', projeto_localRouter);
router.use('/tipo_acao', tipo_acaoRouter);
router.use('/pessoa', pessoaRouter);
router.use('/local_execucao', local_execucaoRouter);

module.exports = router;        