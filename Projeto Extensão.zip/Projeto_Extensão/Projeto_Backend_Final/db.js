// arquivo db.js
const mysql = require('mysql2/promise');
const pool = mysql.createPool({
 host: '127.0.0.1', // porta do banco de dados  ALTER USER 'mariorgmfilho'@'%' IDENTIFIED BY 'Nat99Ath05';
 user: 'root', // usuario do mysql
 password: 'P@ssw0rd', // senha do usuario do mysql
 database: 'projetos_extensao', // nome do banco de dados
 port: 3306,
 waitForConnections: true,
 connectionLimit: 10,
 queueLimit: 0
});
module.exports = pool; 
